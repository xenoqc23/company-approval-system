'use strict';
(async()=>{
  const container=document.getElementById('document-content');
  const target=new URLSearchParams(location.search).get('target')||'pending';
  try{
    const response=await fetch('/api/document?target='+encodeURIComponent(target),{cache:'no-store'});
    const data=await response.json();if(!response.ok)throw new Error(data.error||'문서 확인에 실패했습니다.');
    const cards=data.documents.map(doc=>{
      const card=document.createElement('article');card.className='card';
      const heading=document.createElement('h2');heading.textContent=doc.kind;
      const who=document.createElement('p');who.textContent=`기안자: ${doc.author} ${doc.rank} · ${doc.department}`;
      const status=document.createElement('p');status.className='badge';status.textContent=doc.status;
      const note=document.createElement('p');note.className='hint';
      note.textContent=data.demo?'알림 디자인을 확인하기 위한 시연 문서입니다. 저장한 가상 미결 문서의 상태와는 별개입니다.':'이 PC에 저장한 가상 문서입니다.';
      card.append(heading,who,status,note);return card;
    });
    if(!cards.length){const empty=document.createElement('p');empty.className='state';empty.textContent='현재 확인할 가상 미결 문서가 없습니다.';cards.push(empty);}
    container.replaceChildren(...cards);
  }catch(error){container.textContent=error.message;}
})();
