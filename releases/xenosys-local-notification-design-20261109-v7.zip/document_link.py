"""Restricted local document activation; never accepts a remote URL or command."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import webbrowser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, build_opener

ROOT = Path(__file__).resolve().parent
SCHEME = 'xenosys-approval-trial'
TARGETS = ('pending', 'trial-leave', 'trial-purchase', 'demo-request', 'demo-completed')


def activation_uri(target='pending'):
    if target not in TARGETS:
        raise ValueError('올바른 가상 문서를 선택해 주세요.')
    return f'{SCHEME}://open/{target}'


def parse_activation(uri):
    if not isinstance(uri, str) or len(uri) > 150:
        raise ValueError('올바른 로컬 문서 링크가 아닙니다.')
    for target in TARGETS:
        if uri == activation_uri(target):
            return target
    raise ValueError('올바른 로컬 문서 링크가 아닙니다.')


def local_url(target, port=18110):
    activation_uri(target)
    return f'http://127.0.0.1:{port}/documents?target={target}'


def identity(root, data_dir):
    text = str(Path(root).resolve()) + '\n' + str(Path(data_dir).resolve())
    return hashlib.sha256(text.encode()).hexdigest()


def open_document(uri, *, root=ROOT, data_dir=None):
    target = parse_activation(uri)
    root = Path(root).resolve()
    data_dir = Path(data_dir).resolve() if data_dir else root/'.local-test-data'
    # Only a fixed loopback endpoint is probed. Browser cookies are not used.
    opener = build_opener(ProxyHandler({}))
    try:
        with opener.open('http://127.0.0.1:18110/api/identity', timeout=2) as response:
            info = json.loads(response.read(1024))
    except HTTPError as exc:
        raise RuntimeError('다른 로컬 테스트가 실행 중입니다. 기존 검은 실행 창을 닫고 다시 눌러 주세요.') from exc
    except URLError:
        python = root/'.venv'/('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        if not python.is_file():
            raise RuntimeError('먼저 이 폴더의 START_TEST.bat을 한 번 실행해 주세요.')
        subprocess.Popen([str(python), str(root/'server.py'), '--open-document', target,
                          '--data-dir', str(data_dir)], cwd=root,
                         creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))
        return 'started'
    if info != {'trial': identity(root, data_dir)}:
        raise RuntimeError('다른 폴더의 테스트가 실행 중입니다. 기존 검은 실행 창을 닫고 다시 눌러 주세요.')
    webbrowser.open(local_url(target))
    return 'opened'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('uri')
    parser.add_argument('--data-dir', type=Path, default=ROOT/'.local-test-data')
    args = parser.parse_args()
    try:
        open_document(args.uri, data_dir=args.data_dir)
    except (ValueError, OSError, RuntimeError) as exc:
        message = str(exc)
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, '사내결재 로컬 문서 확인', 0x10)
        elif sys.stderr:
            print(message, file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
