'use strict';
const messages={
  request:{title:'결재 요청',body:'홍길동 대리 · 개발팀\n휴가원 · 검토를 기다리고 있습니다.'},
  completed:{title:'결재 완료',body:'김가영 과장 · 생산팀\n구매요청서 · 최종 승인이 완료되었습니다.'}
};
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('push',event=>{
  let payload={};try{payload=event.data?event.data.json():{};}catch{}
  const message=messages[payload.kind]||{title:'[테스트] PC 알림',body:'로컬 PC 알림 테스트입니다.'};
  event.waitUntil(self.registration.showNotification(message.title,{body:message.body,
    icon:'/company-logo.png',image:'/company-logo.png',
    tag:typeof payload.tag==='string'?payload.tag:'local-push-test',requireInteraction:true,
    actions:[{action:'view',title:'문서 확인'},{action:'acknowledge',title:'닫기'}],
    data:{localTrial:true,target:payload.kind==='completed'?'demo-completed':'demo-request'}}));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  if(event.action==='acknowledge')return;
  event.waitUntil((async()=>{
    const allowed=['pending','trial-leave','trial-purchase','demo-request','demo-completed'];
    const selection=event.notification.data?.target;
    const target=self.location.origin+'/documents?target='+(allowed.includes(selection)?selection:'pending');
    const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    const existing=windows.find(client=>new URL(client.url).origin===self.location.origin);
    if(existing){await existing.navigate(target);return existing.focus();}
    return self.clients.openWindow(target);
  })());
});
