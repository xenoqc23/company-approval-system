"""Native reminder content; acknowledgement dismisses only the notification."""
from xml.etree.ElementTree import Element,SubElement,tostring


def reminder_xml(title,body,footer,*,logo=None,target=None):
    toast=Element('toast',scenario='reminder')
    if target:
        from document_link import parse_activation
        parse_activation(target)
        toast.set('activationType','protocol');toast.set('launch',target)
    binding=SubElement(SubElement(toast,'visual'),'binding',template='ToastGeneric')
    SubElement(binding,'text').text=title
    if logo:SubElement(binding,'image',src=logo,alt='XENOSYS 회사 로고')
    SubElement(binding,'text').text=body
    SubElement(binding,'text',placement='attribution').text=footer
    actions=SubElement(toast,'actions')
    if target:SubElement(actions,'action',content='문서 확인',arguments=target,activationType='protocol')
    SubElement(actions,'action',content='닫기' if target else '확인',arguments='dismiss',activationType='system')
    SubElement(toast,'audio',silent='true')
    return tostring(toast,encoding='unicode')
