from django import forms
from .models import Announcement,AnnouncementAttachment
from .announcement_files import validate_files


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected=True


class MultipleFileField(forms.FileField):
    widget=MultipleFileInput
    def clean(self,data,initial=None):
        if not data:return []
        return [super(MultipleFileField,self).clean(value,initial) for value in (data if isinstance(data,(list,tuple)) else [data])]


class AnnouncementForm(forms.ModelForm):
    body=forms.CharField(label='내용',max_length=20000,widget=forms.Textarea(attrs={'rows':14,'placeholder':'직원들에게 안내할 내용을 작성해 주세요.'}))
    version=forms.IntegerField(min_value=1,widget=forms.HiddenInput)
    files=MultipleFileField(label='첨부파일 추가',required=False,widget=MultipleFileInput(attrs={'accept':'.zip,.pdf,.png,.jpg,.jpeg,.gif,.webp,.xlsx,.xls,.docx,.doc,.hwp,.hwpx,.txt,.pptx,.ppt'}))
    remove_files=forms.ModelMultipleChoiceField(label='삭제할 첨부파일',queryset=AnnouncementAttachment.objects.none(),required=False,widget=forms.CheckboxSelectMultiple)
    class Meta:
        model=Announcement
        fields=['title','body','pinned','version','files','remove_files']
        labels={'title':'제목','body':'내용','pinned':'목록 상단에 고정'}
        widgets={'title':forms.TextInput(attrs={'placeholder':'공지 제목을 입력해 주세요.'}),
                 'body':forms.Textarea(attrs={'rows':14,'placeholder':'직원들에게 안내할 내용을 작성해 주세요.'})}
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.instance.pk:
            self.fields['version'].initial=self.instance.revision
            self.fields['remove_files'].queryset=self.instance.attachments.filter(removed_at=None)
        else:
            self.fields.pop('version');self.fields.pop('remove_files')
    def clean_body(self):
        value=self.cleaned_data['body'].strip()
        if not value:raise forms.ValidationError('공지 내용을 입력해 주세요.')
        return value
    def clean(self):
        data=super().clean()
        if 'files' not in data:return data
        removed=data.get('remove_files',AnnouncementAttachment.objects.none())
        remaining=self.instance.attachments.filter(removed_at=None).exclude(pk__in=[f.pk for f in removed]) if self.instance.pk else []
        try:validate_files(data['files'],remaining)
        except forms.ValidationError as error:self.add_error('files',error)
        return data
