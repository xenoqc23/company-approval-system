'use strict';
const editor=document.querySelector('[data-announcement-editor]');
if(editor){
  const button=editor.querySelector('button[type=submit]');
  const status=editor.querySelector('[data-announcement-saving]');
  const label=button.textContent;
  editor.addEventListener('submit',()=>{
    button.disabled=true;button.textContent='저장 중…';
    status.hidden=false;status.textContent='글과 첨부파일을 저장하고 있습니다. 잠시 기다려 주세요.';
  });
  window.addEventListener('pageshow',()=>{button.disabled=false;button.textContent=label;status.hidden=true;});
}
