"""Private board attachments share the verified backup root with purchase files."""
import logging
import os
from pathlib import Path
from uuid import uuid4
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.storage import FileSystemStorage

MAX_BYTES=100*1024*1024
MAX_TOTAL_BYTES=200*1024*1024
MAX_FILES=5
EXTENSIONS={'.exe','.zip','.pdf','.png','.jpg','.jpeg','.gif','.webp','.xlsx','.xls','.docx','.doc','.hwp','.hwpx','.txt','.pptx','.ppt'}


class AnnouncementStorage(FileSystemStorage):
    @property
    def base_location(self):return str(settings.DATA_DIR/'purchase-attachments')
    @property
    def location(self):return os.path.abspath(self.base_location)


def private_storage():return AnnouncementStorage(base_url=None)


def attachment_path(instance,name):
    return f'announcements/{instance.announcement_id}/{uuid4().hex}{Path(name).suffix.lower()}'


def validate_files(files,remaining):
    files=list(files);remaining=list(remaining)
    if len(files)+len(remaining)>MAX_FILES:raise ValidationError('첨부파일은 공지당 최대 5개까지 등록할 수 있습니다.')
    for file in files:
        name=file.name
        if not name or len(name)>200 or '/' in name or '\\' in name or any(ord(c)<32 for c in name):raise ValidationError('파일 이름은 경로·제어문자 없이 200자 이내로 지정해 주세요.')
        if Path(name).suffix.lower() not in EXTENSIONS:raise ValidationError('EXE·ZIP·PDF·이미지·엑셀·워드·한글·PPT·텍스트 파일을 첨부해 주세요.')
        if not 0<file.size<=MAX_BYTES:raise ValidationError('빈 파일은 첨부할 수 없으며 파일당 최대 100MB입니다.')
    if sum(file.size for file in files)+sum(file.size for file in remaining)>MAX_TOTAL_BYTES:
        raise ValidationError('공지 한 건의 첨부파일 합계는 최대 200MB입니다.')
    return files


def installer_attachment(files):
    files=list(files)
    return next((f for f in files if Path(f.original_name).suffix.lower()=='.exe'),
                next((f for f in files if Path(f.original_name).suffix.lower()=='.zip'),None))


def clean_removed_files(files):
    for storage,name in files:
        try:storage.delete(name)
        except OSError:logging.getLogger(__name__).warning('Announcement attachment cleanup could not finish.')


class NewFiles:
    def __init__(self):self.saved=[]
    def __enter__(self):return self
    def __exit__(self,kind,error,traceback):
        if kind:clean_removed_files(self.saved)
    def add(self,announcement,user,files):
        from .models import AnnouncementAttachment
        for file in files:
            attachment=AnnouncementAttachment(announcement=announcement,uploaded_by=user,original_name=file.name,size=file.size)
            attachment.file.save(file.name,file,save=False)
            self.saved.append((attachment.file.storage,attachment.file.name))
            attachment.save()
