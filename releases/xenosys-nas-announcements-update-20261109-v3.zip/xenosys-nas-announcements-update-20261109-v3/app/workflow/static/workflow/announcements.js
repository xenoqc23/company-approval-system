'use strict';
const editor=document.querySelector('[data-announcement-editor]');
if(editor){
  editor.querySelector('[data-install-template]')?.addEventListener('click',()=>{
    const title=editor.querySelector('[name=title]'),body=editor.querySelector('[name=body]');
    editor.querySelector('[name=install_guide]').checked=true;
    if(!title.value.trim())title.value='사내결재 PC 알림 프로그램 설치 안내';
    if(!body.value.trim())body.value='직원 여러분께 안내드립니다.\n\n결재 요청과 처리 결과를 PC에서 바로 확인할 수 있는 알림 프로그램입니다.\n아래 다운로드 버튼으로 설치 파일을 받고, 안내 순서에 따라 본인 계정을 연결해 주세요.';
  });
  const button=editor.querySelector('button[type=submit]');
  const status=editor.querySelector('[data-announcement-saving]');
  const label=button.textContent;
  editor.addEventListener('submit',()=>{
    button.disabled=true;button.textContent='저장 중…';
    status.hidden=false;status.textContent='글과 첨부파일을 저장하고 있습니다. 잠시 기다려 주세요.';
  });
  window.addEventListener('pageshow',()=>{button.disabled=false;button.textContent=label;status.hidden=true;});
}
