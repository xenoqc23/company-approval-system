from functools import wraps,partial
from pathlib import Path
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Q,Count
from django.http import FileResponse,Http404
from django.shortcuts import get_object_or_404,redirect,render
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET,require_POST,require_http_methods
from .announcement_forms import AnnouncementForm
from .announcement_files import NewFiles,clean_removed_files,private_storage,installer_attachment
from .models import Announcement,AnnouncementAttachment
from .services import audit
from .pc_notifier_notice import NOTICE_KEY


def employee(view):
    @wraps(view)
    def checked(request,*args,**kwargs):
        profile=getattr(request.user,'profile',None)
        if not request.user.is_active or not profile or not profile.approved or profile.must_change_password:raise PermissionDenied
        return view(request,*args,**kwargs)
    return login_required(never_cache(checked))


def manager(view):
    @wraps(view)
    def checked(request,*args,**kwargs):
        if not request.user.profile.manage_system or request.user.profile.is_representative:raise PermissionDenied('공지 작성·수정·삭제는 관리자만 할 수 있습니다.')
        return view(request,*args,**kwargs)
    return employee(checked)


def page(request,name,**data):
    return render(request,f'workflow/announcements/{name}.html',dict(title='공지사항',section='announcements',can_manage=request.user.profile.manage_system and not request.user.profile.is_representative,**data))


@employee
@require_GET
def index(request):
    query=request.GET.get('q','').strip()[:120]
    rows=Announcement.objects.filter(deleted_at=None).select_related('author').annotate(file_count=Count('attachments',filter=Q(attachments__removed_at=None))).order_by('-pinned','-created_at','-pk')
    if query:rows=rows.filter(Q(title__icontains=query)|Q(body__icontains=query))
    return page(request,'index',rows=Paginator(rows,20).get_page(request.GET.get('page')),query=query)


@employee
@require_GET
def detail(request,pk):
    announcement=get_object_or_404(Announcement.objects.select_related('author','updated_by'),pk=pk,deleted_at=None)
    files=list(announcement.attachments.filter(removed_at=None).order_by('pk'))
    installer=installer_attachment(files) if announcement.install_guide else None
    return page(request,'detail',announcement=announcement,files=[f for f in files if not installer or f.pk!=installer.pk],installer=installer,
                installer_is_exe=bool(installer and Path(installer.original_name).suffix.lower()=='.exe'),
                installer_steps_in_body=announcement.publication_key==NOTICE_KEY)


@manager
@require_http_methods(['GET','POST'])
def create(request):
    form=AnnouncementForm(request.POST if request.method=='POST' else None,request.FILES if request.method=='POST' else None)
    if request.method=='POST' and form.is_valid():
        with NewFiles() as saved:
            with transaction.atomic():
                announcement=form.save(commit=False);announcement.author=request.user;announcement.updated_by=request.user;announcement.save()
                saved.add(announcement,request.user,form.cleaned_data['files'])
                audit(request.user,'공지사항 등록',detail=f'공지 #{announcement.pk}: {announcement.title}')
        messages.success(request,'공지사항을 등록했습니다.')
        return redirect('announcement_detail',pk=announcement.pk)
    return page(request,'form',form=form,announcement=None)


@manager
@require_http_methods(['GET','POST'])
def edit(request,pk):
    data=request.POST if request.method=='POST' else None
    files=request.FILES if request.method=='POST' else None
    conflict=False
    with NewFiles() as saved:
        with transaction.atomic():
            qs=Announcement.objects.select_for_update() if request.method=='POST' else Announcement.objects
            announcement=get_object_or_404(qs,pk=pk,deleted_at=None)
            form=AnnouncementForm(data,files,instance=announcement)
            if request.method=='POST' and form.is_valid():
                if form.cleaned_data['version']!=announcement.revision:
                    form.add_error(None,'다른 관리자가 이 공지를 수정했습니다. 새로고침하여 최신 내용을 확인한 뒤 다시 저장해 주세요.');conflict=True
                else:
                    announcement=form.save(commit=False);announcement.updated_by=request.user;announcement.updated_at=timezone.now();announcement.revision+=1;announcement.save()
                    removed=list(form.cleaned_data['remove_files']);old_files=[(f.file.storage,f.file.name) for f in removed]
                    AnnouncementAttachment.objects.filter(pk__in=[f.pk for f in removed]).update(removed_at=timezone.now())
                    saved.add(announcement,request.user,form.cleaned_data['files'])
                    transaction.on_commit(partial(clean_removed_files,old_files))
                    audit(request.user,'공지사항 수정',detail=f'공지 #{announcement.pk}: {announcement.title}')
                    messages.success(request,'공지사항을 수정했습니다.')
                    return redirect('announcement_detail',pk=announcement.pk)
    response=page(request,'form',form=form,announcement=announcement)
    if conflict:response.status_code=409
    return response


@manager
@require_POST
def delete(request,pk):
    with transaction.atomic():
        announcement=get_object_or_404(Announcement.objects.select_for_update(),pk=pk,deleted_at=None)
        if request.POST.get('version')!=str(announcement.revision):
            response=page(request,'conflict',announcement=announcement);response.status_code=409;return response
        files=list(announcement.attachments.filter(removed_at=None))
        announcement.deleted_at=timezone.now();announcement.updated_by=request.user;announcement.revision+=1
        announcement.save(update_fields=['deleted_at','updated_by','revision'])
        announcement.attachments.filter(removed_at=None).update(removed_at=announcement.deleted_at)
        transaction.on_commit(partial(clean_removed_files,[(f.file.storage,f.file.name) for f in files]))
        audit(request.user,'공지사항 삭제',detail=f'공지 #{announcement.pk}: {announcement.title}')
    messages.success(request,'공지사항을 삭제했습니다.')
    return redirect('announcements')


@employee
@require_GET
def download(request,pk):
    attachment=get_object_or_404(AnnouncementAttachment,pk=pk,removed_at=None,announcement__deleted_at=None)
    if not attachment.file.name.startswith(f'announcements/{attachment.announcement_id}/'):raise Http404
    root=Path(private_storage().location)
    path=Path(attachment.file.path)
    if root.is_symlink() or path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):raise Http404
    try:handle=attachment.file.open('rb')
    except OSError:raise Http404('첨부파일을 찾을 수 없습니다.')
    response=FileResponse(handle,as_attachment=True,filename=attachment.original_name,content_type='application/octet-stream')
    response['X-Content-Type-Options']='nosniff'
    response['Content-Security-Policy']="default-src 'none'"
    return response
