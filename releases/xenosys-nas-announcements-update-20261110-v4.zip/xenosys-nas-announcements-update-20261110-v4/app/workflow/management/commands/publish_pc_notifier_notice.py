from django.core.management.base import BaseCommand
from workflow.pc_notifier_notice import installer_path, publish


class Command(BaseCommand):
    help = '검증한 PC 알림 설치 파일과 수정 가능한 공지를 최초 한 번 등록'

    def add_arguments(self, parser):
        modes = parser.add_mutually_exclusive_group(required=True)
        modes.add_argument('--check', action='store_true')
        modes.add_argument('--publish', action='store_true')

    def handle(self, *args, **options):
        if options['check']:
            installer_path()
            self.stdout.write('공지용 PC 설치 파일 무결성 확인 완료. 공지는 변경하지 않았습니다.')
            return
        notice, created = publish()
        self.stdout.write(f'설치 안내 공지 #{notice.pk} 등록 완료. 공지사항에서 수정할 수 있습니다.' if created
                          else '이미 등록한 설치 안내입니다. 기존 수정·삭제 상태와 첨부를 유지합니다.')
