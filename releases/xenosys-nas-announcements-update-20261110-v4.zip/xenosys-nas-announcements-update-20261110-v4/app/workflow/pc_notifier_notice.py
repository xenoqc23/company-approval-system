"""Publish the requested, editable install notice once during a guarded update."""
import hashlib
import json
from pathlib import Path

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files import File
from django.core.management.base import CommandError
from django.db import transaction

from .announcement_files import MAX_BYTES, NewFiles
from .models import Announcement
from .services import audit

NOTICE_KEY = 'pc-notifier-install-20261110'
NOTICE_TITLE = '사내결재시스템 알림 설치'
INSTALLER_NAME = 'XenosysApprovalSetup.exe'
NOTICE_BODY = '''직원 여러분께 안내드립니다.
결재 요청과 처리 결과를 PC에서 확인할 수 있도록 사내결재 알림 프로그램을 설치해 주세요.
이미 프로그램을 설치하고 본인 계정 연결까지 완료한 직원은 다시 설치하지 않아도 됩니다.

■ 설치 방법
1. 위의 ‘알림 프로그램 다운로드’ 버튼을 눌러 설치 파일을 받습니다.
2. 다운로드한 XenosysApprovalSetup.exe를 실행합니다. ZIP 압축 해제나 별도 .NET 설치는 필요 없습니다.
3. ‘이 PC에 설치’를 누르고 ‘Windows 로그인 시 자동 실행’을 켜 둡니다.
4. 프로그램의 사내결재시스템 주소가 https://xenonas.synology.me:18443 인지 확인하고 ‘본인 계정 연결’을 누릅니다.
5. 열린 홈페이지에서 본인 계정으로 로그인합니다. 프로그램과 홈페이지의 확인 코드가 같은지 확인한 뒤 ‘이 계정으로 PC 연결’을 누릅니다.
6. ‘계정이 연결됐습니다’가 나오면 알림 프로그램으로 돌아가 연결 상태를 확인합니다. 홈페이지 창은 닫아도 됩니다.

■ 사용 안내
• 브라우저를 열어 두거나 닫아도 PC 알림 프로그램이 실행 중이면 알림을 받을 수 있습니다.
• Windows 로그인 후 프로그램이 자동 실행되면 남아 있는 미결 문서를 확인합니다. 인터넷 연결과 NAS 접속이 가능해야 합니다.
• PC 프로그램에 연결한 계정을 기준으로 알림을 받습니다. 다른 직원의 계정으로 연결하지 마세요.
• ‘문서 확인’을 누르면 해당 문서가 열립니다. 알림을 닫는 것만으로 결재가 완료되지는 않습니다.
• 설치 후에는 설치된 프로그램을 삭제하지 말고 유지해 주세요.

■ 지원 환경
Windows 10 22H2 또는 Windows 11, 64비트 PC용입니다.
다운로드 버튼을 누르는 것만으로 설치가 자동 실행되지는 않습니다. 받은 파일을 직접 실행해 주세요.
'''


def installer_path():
    folder = Path(settings.BASE_DIR) / 'deploy/nas/notifier'
    path = folder / INSTALLER_NAME
    try:
        metadata = json.loads((folder / 'INSTALLER.json').read_text())
        content = path.read_bytes()
        if (not 0 < len(content) <= MAX_BYTES or content[:2] != b'MZ'
                or metadata['bytes'] != len(content)
                or metadata['sha256'] != hashlib.sha256(content).hexdigest()):
            raise ValueError('Installer checksum mismatch')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise CommandError('공지용 설치 파일을 확인할 수 없습니다. 원본 업데이트 ZIP을 다시 압축 해제해 주세요.') from exc
    return path


def publish():
    from .rollout import RELEASE
    try:
        plan = json.loads((settings.DATA_DIR / 'nas-purchase-update-plan.json').read_text())
        if plan.get('release') != RELEASE or plan.get('applied') is not True:
            raise ValueError('Update not validated')
        operator_id = plan['operator_id']
        if type(operator_id) is not int:
            raise ValueError('Invalid operator')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise CommandError('기존 데이터 보존 검사를 마친 NAS 업데이트에서 실행해 주세요.') from exc
    path = installer_path()
    with NewFiles() as saved, transaction.atomic():
        actor = get_user_model().objects.select_for_update().filter(pk=operator_id, is_active=True,
            profile__approved=True, profile__manage_system=True, profile__representative_slot__isnull=True).first()
        if actor is None:
            raise CommandError('업데이트를 실행한 시스템 관리자 계정을 확인해 주세요.')
        existing = Announcement.objects.filter(publication_key=NOTICE_KEY).first()
        if existing:
            return existing, False
        notice = Announcement.objects.create(title=NOTICE_TITLE, body=NOTICE_BODY, pinned=True,
            install_guide=True, publication_key=NOTICE_KEY, author=actor, updated_by=actor)
        with path.open('rb') as stream:
            saved.add(notice, actor, [File(stream, name=INSTALLER_NAME)])
        audit(actor, '공지사항 등록', detail=f'공지 #{notice.pk}: {notice.title} (요청한 설치 안내 최초 등록)')
    return notice, True
