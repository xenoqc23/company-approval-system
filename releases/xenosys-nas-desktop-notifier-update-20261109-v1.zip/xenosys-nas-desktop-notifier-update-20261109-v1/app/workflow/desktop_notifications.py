"""Current per-user work, independent of notice cursors and browser sessions."""
from django.conf import settings
from django.db.models import Q
from django.urls import reverse
from .completion import owner_completed
from .live_notifications import waiting_documents


def person(user):
    return dict(name=user.first_name or user.username, department=user.profile.department, rank=user.profile.rank)


def entry(key, document, category, kind, title, owner, path, summary, stamp):
    return dict(id=key, document=document, category=category, kind=kind, title=title,
                owner=person(owner), path=path, summary=summary, stamp=stamp.isoformat())


def snapshot(user):
    items=[]
    waiting=waiting_documents(user).select_related('owner__profile')
    if user.profile.is_representative and not user.profile.representative_can_approve:
        waiting=waiting.exclude(status='executive')
    for d in waiting:
        label=d.get_kind_display()
        stage='확인 요청' if d.kind=='stock' and not d.final_approval_required else '검토 요청' if d.status=='review' else '승인 요청'
        summary=(f'{d.start_date} ~ {d.end_date} · {d.get_leave_type_display()}' if d.kind=='leave' else d.product)[:180]
        items.append(entry(f'w:{d.pk}:{d.status}:{d.leave_revision}',f'w:{d.pk}','request',label,
            f'{label} {stage}',d.owner,reverse('detail',args=[d.pk]),summary,d.submitted_at or d.created_at))
    for d in owner_completed(user).filter(completion_seen=False).select_related('owner__profile'):
        kind=d.get_kind_display();stamp=d.completion_stamp
        items.append(entry(f'wc:{d.pk}:{stamp.isoformat()}',f'w:{d.pk}','completed',kind,
            f'{kind} '+('확인 완료' if d.kind=='stock' and not d.final_approval_required else '결재 완료'),
            d.owner,reverse('detail',args=[d.pk]),'문서를 열어 처리 결과를 확인해 주세요.',stamp))
    if settings.INTEGRATED_PURCHASES:
        from purchasing.access import requests_for, checker_requests, finance_requests, reports_for
        from purchasing.models import PurchaseRequest
        pending=requests_for(user).filter(Q(status='review',reviewer=user)|Q(status='approval',approver=user)|Q(status='director',director=user))
        seen=set()
        def purchase(d,category,title,suffix):
            seen.add(d.pk)
            items.append(entry(f'p:{d.pk}:{d.revision}:{d.status}:{suffix}',f'p:{d.pk}',category,'구매요청서',title,
                d.owner,reverse('purchasing:detail',args=[d.pk]),d.product[:180],d.submitted_at or d.created_at))
        for d in pending.select_related('owner__profile'):
            purchase(d,'request','구매요청서 '+('검토 요청' if d.status=='review' else '승인 요청'),'action')
        for d in checker_requests(user).filter(status__in=['ready','hold'],confirmed_at=None).select_related('owner__profile'):
            if d.pk not in seen:purchase(d,'request','구매 내용 확인 요청','check')
        finance=finance_requests(user).filter(Q(status__in=['ready','reapproval'])|Q(status='hold',hold_ready=True)|Q(status='ceo',current_report__payment_tracking=True,current_report__created_by=user)).filter(confirmed_at__isnull=False)
        for d in finance.select_related('owner__profile'):
            if d.pk not in seen:purchase(d,'request','구매요청 취합·처리 대기','finance')
        for d in PurchaseRequest.objects.filter(owner=user,completion_unread=True).exclude(status__in=['draft','cancelled']).select_related('owner__profile'):
            purchase(d,'completed','구매요청서 · '+d.get_status_display(),'completion')
        for r in reports_for(user).filter(representative=user,status='pending').filter(Q(payment_tracking=False)|Q(representative_viewed_at=None)).select_related('created_by__profile'):
            items.append(entry(f'r:{r.pk}:{r.revision}',f'r:{r.pk}','request','구매요청 묶음',
                '구매요청 확인' if r.payment_tracking else '구매요청 승인 요청',r.created_by,
                reverse('purchasing:report_detail',args=[r.pk]),r.title,r.created_at))
    items.sort(key=lambda row:(row['stamp'],row['id']))
    return dict(version=1,user=dict(id=user.pk,**person(user)),items=items,
                waiting=sum(row['category']=='request' for row in items),
                completed=sum(row['category']=='completed' for row in items),poll_seconds=15)
