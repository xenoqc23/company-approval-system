"""Browser-consented device pairing; app tokens grant notification reads only."""
import hashlib
import json
import secrets
import re
from datetime import timedelta
from functools import wraps
from uuid import UUID
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.db import transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.utils import timezone
from django.utils.crypto import constant_time_compare, salted_hmac
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST, require_http_methods
from .models import DesktopDevice,DesktopPairing


def digest(value):return hashlib.sha256(value.encode()).hexdigest()
def stamp(user):return salted_hmac('xenosys-desktop-password',user.password,algorithm='sha256').hexdigest()
def ready(user):return user.is_active and user.profile.approved and not user.profile.must_change_password


def login_return(request,*,remember=False,pop=False):
    """Only the desktop consent route can resume after login/password change."""
    key='desktop_consent_return'
    path=request.GET.get('next','') if remember else request.session.get(key,'')
    if not isinstance(path,str) or not re.fullmatch(r'/notifications/desktop/connect/[0-9a-fA-F-]{36}/',path):path=''
    if remember:
        if path:request.session[key]=path
        else:request.session.pop(key,None)
    if pop:request.session.pop(key,None)
    return path


def body(request):
    if request.content_type!='application/json' or len(request.body)>4096:raise ValueError('올바른 연결 요청이 필요합니다.')
    value=json.loads(request.body)
    if not isinstance(value,dict):raise ValueError('올바른 연결 요청이 필요합니다.')
    return value


def api(view):
    @wraps(view)
    def wrapped(request,*args,**kwargs):
        try:return view(request,*args,**kwargs)
        except (ValueError,TypeError,UnicodeError):return JsonResponse(dict(error='올바른 요청이 필요합니다.'),status=400)
    return never_cache(wrapped)


def device_required(view):
    @wraps(view)
    def wrapped(request,*args,**kwargs):
        token=request.headers.get('Authorization','')
        if not token.startswith('Bearer xnd_') or len(token)>120:
            return JsonResponse(dict(error='계정을 다시 연결해 주세요.',code='unauthorized'),status=401)
        device=DesktopDevice.objects.select_related('user__profile').filter(token_hash=digest(token[7:]),revoked_at=None).first()
        if not device or not ready(device.user) or not constant_time_compare(device.auth_stamp,stamp(device.user)):
            return JsonResponse(dict(error='계정 연결이 해제되었거나 계정 상태가 변경됐습니다.',code='unauthorized'),status=401)
        request.desktop_device=device
        if device.last_seen<timezone.now()-timedelta(minutes=1):
            DesktopDevice.objects.filter(pk=device.pk).update(last_seen=timezone.now())
        return view(request,*args,**kwargs)
    return wrapped


@csrf_exempt
@require_POST
@api
def pair_start(request):
    data=body(request)
    name=data.get('device_name','내 PC')
    if not isinstance(name,str) or not 1<=len(name.strip())<=80:raise ValueError
    key='desktop-pair-'+digest(request.META.get('REMOTE_ADDR','unknown'))
    attempts=cache.get(key,0)
    if attempts>=30:return JsonResponse(dict(error='잠시 후 다시 시도해 주세요.'),status=429)
    cache.set(key,attempts+1,600)
    DesktopPairing.objects.filter(expires_at__lt=timezone.now()-timedelta(days=1)).delete()
    secret=secrets.token_urlsafe(32)
    pairing=DesktopPairing.objects.create(secret_hash=digest(secret),display_code=secrets.token_hex(3).upper(),
        device_name=name.strip(),expires_at=timezone.now()+timedelta(minutes=10))
    return JsonResponse(dict(pair_id=str(pairing.pk),secret=secret,code=pairing.display_code,expires_in=600,
        verification_path=reverse('desktop_connect',args=[pairing.pk])))


@csrf_exempt
@require_POST
@api
def pair_poll(request):
    data=body(request);secret=data.get('secret')
    if not isinstance(secret,str) or not 20<=len(secret)<=100:raise ValueError
    if not isinstance(data.get('pair_id'),str):raise ValueError
    with transaction.atomic():
        p=DesktopPairing.objects.select_for_update().select_related('user__profile').filter(pk=UUID(data.get('pair_id',''))).first()
        if not p or not constant_time_compare(p.secret_hash,digest(secret)):
            return JsonResponse(dict(error='연결 요청을 확인할 수 없습니다.'),status=400)
        if p.consumed or p.expires_at<timezone.now():return JsonResponse(dict(error='연결 시간이 끝났습니다.',state='expired'),status=410)
        if not p.user_id:return JsonResponse(dict(state='pending'))
        if not ready(p.user):return JsonResponse(dict(error='사용 가능한 계정이 아닙니다.'),status=403)
        token='xnd_'+secrets.token_urlsafe(32)
        device=DesktopDevice.objects.create(user=p.user,name=p.device_name,token_hash=digest(token),auth_stamp=stamp(p.user))
        p.consumed=True;p.save(update_fields=['consumed'])
    from .desktop_notifications import person
    return JsonResponse(dict(state='connected',token=token,device_id=str(device.pk),user=dict(id=p.user_id,**person(p.user))))


@login_required
@never_cache
@require_http_methods(['GET','POST'])
def connect(request,pair_id):
    request.session.pop('desktop_consent_return',None)
    p=get_object_or_404(DesktopPairing,pk=pair_id)
    expired=p.consumed or p.expires_at<timezone.now()
    done=False
    if request.method=='POST' and not expired and ready(request.user):
        with transaction.atomic():
            p=DesktopPairing.objects.select_for_update().get(pk=p.pk)
            if p.user_id and p.user_id!=request.user.pk:
                return render(request,'workflow/desktop_connect.html',dict(pair=p,expired=True),status=409)
            if not p.consumed and p.expires_at>=timezone.now():
                p.user=request.user;p.save(update_fields=['user']);done=True
    return render(request,'workflow/desktop_connect.html',dict(pair=p,expired=expired,done=done))


@require_GET
@api
@device_required
def feed(request):
    from .desktop_notifications import snapshot
    return JsonResponse(snapshot(request.desktop_device.user))


@csrf_exempt
@require_POST
@api
@device_required
def revoke(request):
    request.desktop_device.revoked_at=timezone.now();request.desktop_device.save(update_fields=['revoked_at'])
    return JsonResponse(dict(ok=True))


@login_required
@never_cache
@require_http_methods(['GET','POST'])
def devices(request):
    if request.method=='POST':
        try:device_id=UUID(request.POST.get('device',''))
        except ValueError:device_id=None
        DesktopDevice.objects.filter(pk=device_id,user=request.user,revoked_at=None).update(revoked_at=timezone.now())
        return redirect('desktop_devices')
    return render(request,'workflow/desktop_devices.html',dict(devices=DesktopDevice.objects.filter(user=request.user,revoked_at=None).order_by('-last_seen')))
