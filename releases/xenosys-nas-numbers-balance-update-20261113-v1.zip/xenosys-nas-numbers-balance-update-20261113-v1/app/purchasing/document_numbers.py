"""Search new stored numbers and exact historical PUR numbers without renumbering."""
from datetime import datetime
import re
from django.db.models import Q


def number_query(value):
    result=Q(document_number__icontains=value)
    old=re.fullmatch(r'PUR-(\d{8})-(\d{1,18})',value.upper())
    if old:
        try:day=datetime.strptime(old[1],'%Y%m%d').date()
        except ValueError:return result
        result |= (Q(document_number__isnull=True,pk=int(old[2]),created_at__date=day)
                   & (~Q(status='draft') | Q(submitted_at__isnull=False)))
    return result
