"""Opinions accompany successful actions; rejection reasons remain separate."""
from django.core.exceptions import ValidationError
from .models import ApprovalOpinion

OPINION_ACTIONS = frozenset({'review', 'forward', 'review_final', 'approve', 'escalate'})


def clean_opinion(value):
    value = (value or '').strip()
    if len(value) > 1000:
        raise ValidationError('검토·승인자 의견은 1000자 이내로 입력해 주세요.')
    return value


def save_opinion(actor, action, text, previous_status, *, document=None, purchase_request=None):
    if not text or action not in OPINION_ACTIONS:
        return
    stage = 'review' if previous_status == 'review' else 'executive' if previous_status == 'executive' else 'approval'
    ApprovalOpinion.objects.create(document=document, purchase_request=purchase_request, actor=actor,
        actor_name=actor.first_name or actor.username, actor_rank=actor.profile.rank,
        stage=stage, action=action, text=text)
