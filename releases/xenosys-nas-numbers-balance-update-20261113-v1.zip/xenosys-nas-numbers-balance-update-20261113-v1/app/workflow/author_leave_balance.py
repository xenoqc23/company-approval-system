"""Read-only balances for the leave years shown on the author's approval card."""
from django.utils import timezone
from .models import AnnualBalance


def author_leave_balances(document):
    if document.kind != 'leave':
        return []
    first = document.start_date.year if document.start_date else timezone.localdate().year
    last = document.end_date.year if document.end_date else first
    years = range(first, max(first, last) + 1)
    balances = {b.year: b for b in AnnualBalance.objects.filter(user_id=document.owner_id, year__in=years)}
    return [dict(year=year, registered=year in balances,
                 total=balances[year].total if year in balances else None,
                 remaining=balances[year].remaining if year in balances else None)
            for year in years]
