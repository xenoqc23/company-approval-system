"""Allocate monthly numbers inside the caller's existing submission transaction."""
from django.core.exceptions import ValidationError
from django.db import transaction
from .models import MonthlyDocumentCounter


@transaction.atomic
def next_document_number(kind, day):
    if kind not in {'OFF', 'BUY'}:
        raise ValidationError('문서번호 종류를 확인해 주세요.')
    # The unique key resolves concurrent first-month creation; reload under a
    # row lock before incrementing, including submissions from legacy drafts.
    counter, _ = MonthlyDocumentCounter.objects.get_or_create(
        kind=kind, month=day.replace(day=1))
    counter = MonthlyDocumentCounter.objects.select_for_update().get(pk=counter.pk)
    counter.value += 1
    counter.save(update_fields=['value'])
    return f'XEN-{kind}-{day:%y%m}-{counter.value:04d}'
