document.addEventListener('DOMContentLoaded', () => {
  const editor = document.querySelector('[data-opinion-editor]');
  if (!editor) return;
  const fields = [...document.querySelectorAll('[data-opinion-input]')];
  const sync = () => fields.forEach(field => { field.value = editor.value; });
  editor.addEventListener('input', sync);
  fields.forEach(field => {
    field.form.addEventListener('submit', event => {
      if (!editor.reportValidity()) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      sync();
    }, true);
    field.form.addEventListener('formdata', event => event.formData.set('opinion', editor.value));
  });
  sync();
});
