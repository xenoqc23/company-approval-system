# 구매요청서 품명 표시 · NAS 업데이트

구매요청서 상세 화면의 **신청 내용** 첫 줄에 저장된 **품명**을 표시합니다. 기안자·검토자·승인자가 같은 값을 확인할 수 있습니다. 기존 문서에도 적용되며 이번 변경에 추가 데이터베이스 마이그레이션은 없습니다.

이 ZIP은 `xenosys-nas-numbers-balance-update-20261113-v1` 배포본을 기준으로 만들었습니다.

## NAS 적용

1. `xenosys-nas-purchase-item-name-update-20261124-v1.zip`을 File Station의 **docker → company-approval → updates**에 올리고 현재 폴더에 압축을 풉니다.
2. NAS에 SSH로 접속해 사전점검을 실행합니다.

```sh
sudo sh /volume1/docker/company-approval/updates/xenosys-nas-purchase-item-name-update-20261124-v1/UPDATE_NAS.sh precheck --operator admin
```

3. `Precheck complete`가 표시되면 업데이트를 실행합니다. 운영 계정명이 다르면 두 명령의 `admin`을 해당 계정명으로 바꿉니다. 기존 구매 담당자 설정을 유지하려면 담당자 재지정 옵션은 생략합니다.

```sh
sudo sh /volume1/docker/company-approval/updates/xenosys-nas-purchase-item-name-update-20261124-v1/UPDATE_NAS.sh update --operator admin
```

업데이트 중 웹 서비스가 잠시 중지됩니다. 기존 배포 스크립트가 업데이트 전 백업을 생성하고 데이터와 첨부파일 보존을 검사합니다. `Update complete`가 표시되면 기존 구매요청서를 열어 신청 내용 첫 줄의 품명을 확인합니다.

## 복구

복구는 업데이트 전 백업을 사용합니다. 업데이트 이후에 입력한 자료가 있으면 복구 전에 시점을 확인합니다.

```sh
sudo sh /volume1/docker/company-approval/updates/xenosys-nas-purchase-item-name-update-20261124-v1/UPDATE_NAS.sh rollback
```
