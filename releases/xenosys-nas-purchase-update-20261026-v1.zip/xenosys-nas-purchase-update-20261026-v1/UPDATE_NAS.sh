#!/bin/sh
set -eu
umask 077
RELEASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$RELEASE_DIR"
case "${1:-help}" in
  precheck|update|rollback|status|logs|backup) ;;
  *) echo 'Usage: sudo sh UPDATE_NAS.sh precheck|update [role options] | status | logs | rollback | backup'; exit 1;;
esac
sha256sum -c SHA256SUMS > /dev/null || { echo 'Release file verification failed. Extract the original ZIP again.' >&2; exit 1; }
exec sh "$RELEASE_DIR/app/deploy/nas/nas.sh" "$@"
