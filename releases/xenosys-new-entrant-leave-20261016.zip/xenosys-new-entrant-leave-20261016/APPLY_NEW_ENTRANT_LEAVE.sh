#!/bin/sh
set -eu
umask 077
stage=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
base=${APPROVAL_NEW_ENTRANT_BASE:-/volume1/docker/company-approval}
case "$base" in /*) ;; *) echo 'Use an absolute application folder.' >&2; exit 1;; esac
case "$base" in /|/volume1|/volume1/docker|/workspace|/tmp) echo 'Use the existing dedicated application folder.' >&2; exit 1;; esac
app="$base/app"
[ -f "$app/manage.py" ] && [ -f "$app/deploy/nas/nas.sh" ] || { echo 'Existing approval installation not found.' >&2; exit 1; }
[ -w "$app" ] || { echo 'Run this script with sudo.' >&2; exit 1; }
for marker in .pending-image .recovery-in-progress .operation.lock; do
    [ ! -e "$base/$marker" ] || { echo 'Another update or recovery is pending. Do not overwrite source files.' >&2; exit 1; }
done
command -v sha256sum >/dev/null || { echo 'sha256sum is required to verify the update.' >&2; exit 1; }
(cd "$stage" && sha256sum -c SHA256SUMS)
files='workflow/models.py
workflow/services.py
workflow/forms.py
workflow/views.py
workflow/urls.py
workflow/leave_records.py
workflow/manual_leave.py
workflow/migrations/0010_manualleaveusage.py
workflow/templates/workflow/balances.html
workflow/templates/workflow/leave_history.html
workflow/templates/workflow/manual_leave_form.html
workflow/static/workflow/manual-leave.css
workflow/static/workflow/manual-leave.js
workflow/exports.py
workflow/annual_grants.py
workflow/regulations.py
workflow/policy_defaults.py
workflow/migrations/0011_hire_year_monthly.py
workflow/templates/workflow/regulations.html
workflow/templates/workflow/policy.html
workflow/templates/workflow/welfare.html
workflow/templates/workflow/recalculate.html
workflow/templates/workflow/new_entrant_rule.html'
for file in $files; do
    [ -s "$stage/app/$file" ] || { echo 'Update file missing.' >&2; exit 1; }
done
backup=$(mktemp -d "$base/.new-entrant-leave-backup.XXXXXX")
for file in $files; do
    mkdir -p "$backup/$(dirname "$file")" "$app/$(dirname "$file")"
    if [ -f "$app/$file" ]; then
        cp -p "$app/$file" "$backup/$file"
    else
        printf '%s\n' "$file" >> "$backup/NEW_FILES.txt"
    fi
done
printf 'NEW_ENTRANT_SOURCE_BACKUP: %s\n' "$backup"
for file in $files; do
    cp "$stage/app/$file" "$app/$file"
done
sh "$app/deploy/nas/nas.sh" update
echo NEW_ENTRANT_LEAVE_READY
