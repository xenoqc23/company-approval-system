#!/bin/sh
set -eu
umask 077
stage=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
base=${APPROVAL_WORK_STATUS_BASE:-/volume1/docker/company-approval}
case "$base" in /*) ;; *) echo 'Use an absolute application folder.' >&2; exit 1;; esac
case "$base" in /|/volume1|/volume1/docker|/workspace|/tmp) echo 'Use the existing dedicated application folder.' >&2; exit 1;; esac
app="$base/app"
[ -f "$app/manage.py" ] && [ -f "$app/deploy/nas/nas.sh" ] || { echo 'Existing approval installation not found.' >&2; exit 1; }
# This display patch needs the previously installed manual-leave feature.
[ -f "$app/workflow/manual_leave.py" ] || { echo 'Install the manual-leave feature before this display update.' >&2; exit 1; }
# Refuse installers without the existing backup-before-migrate update path.
[ -f "$base/.env" ] || { echo 'Existing private NAS configuration not found.' >&2; exit 1; }
grep -q 'backup_name=$(run_manage backup_database --kind update)' "$app/deploy/nas/nas.sh" || { echo 'The existing NAS updater with database backup is required.' >&2; exit 1; }
[ -w "$app" ] || { echo 'Run this script with sudo.' >&2; exit 1; }
for marker in .pending-image .recovery-in-progress .operation.lock; do
    [ ! -e "$base/$marker" ] || { echo 'Another update or recovery is pending. Do not overwrite source files.' >&2; exit 1; }
done
command -v sha256sum >/dev/null || { echo 'sha256sum is required to verify the update.' >&2; exit 1; }
(cd "$stage" && sha256sum -c SHA256SUMS)
files='workflow/calendars.py
workflow/leave_records.py
workflow/templates/workflow/dashboard.html
workflow/templates/workflow/balances.html
workflow/templates/workflow/calendar.html
workflow/templates/workflow/mobile_calendar_agenda.html
workflow/static/workflow/work-status.css'
for file in $files; do
    [ -s "$stage/app/$file" ] || { echo 'Update file missing.' >&2; exit 1; }
done
backup=$(mktemp -d "$base/.work-status-backup.XXXXXX")
for file in $files; do
    mkdir -p "$backup/$(dirname "$file")" "$app/$(dirname "$file")"
    if [ -f "$app/$file" ]; then
        cp -p "$app/$file" "$backup/$file"
    else
        printf '%s\n' "$file" >> "$backup/NEW_FILES.txt"
    fi
done
printf 'UI_SOURCE_BACKUP: %s\n' "$backup"
for file in $files; do
    cp "$stage/app/$file" "$app/$file"
done
sh "$app/deploy/nas/nas.sh" update
echo WORK_STATUS_READY
